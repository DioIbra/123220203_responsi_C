
/**
 *
 * @author Lab Informatika
 */

public class RentalController {
    public RentalView view;
    public RentalDAO model;

    public RentalController(RentalView view, RentalDAO model) {
        this.view = view;
        this.model = model;
        this.view.tambahRentalSewa(new tambahRentalSewa());
        this.view.hapusRentalSewa(new hapusRentalSewa());
    }

    private static class EditRentalSewa {

        public EditRentalSewa() {
        }
    }

    private static class ActionEvent {

        public ActionEvent() {
        }
    }

    private static class editRentalSewa extends EditRentalSewa {

        public editRentalSewa() {
        }
    }

    class tambahRentalSewa implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String namaPenyewa = view.getnamaPenyewa();
            String namaBuku = view.getnamaBuku();
            String tipeBuku = view.gettipeBuku();
            String nomor = view.getnomor();
            int durasi = view.getdurasi();

            Rental rental = new Rental(namaPenyewa, namaBuku, tipeBuku, nomor, durasi);
            model.tambahRental(rental);
            view.updateRentalList(model.getRentals());
        }
    }

    class EditRentalsewa implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedRow = view.getSelectedRow();
            if (selectedRow >= 0) {
            String namaPenyewa = view.getnamaPenyewa();
            String namaBuku = view.getnamaBuku();
            String tipeBuku = view.gettipeBuku();
            String nomor = view.getnomor();
            int durasi = view.getdurasi();

                Rental rental = new Rental(namaPenyewa, namaBuku, tipeBuku, nomor, durasi);
                model.updateRental(selectedRow, rental);
                view.updateRentalList(model.getRentals());
            }
        }
    }

    class hapusRentalSewa implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedRow = view.getSelectedRow();
            if (selectedRow >= 0) {
                model.hapusRental(selectedRow);
                view.updateRentalList(model.getRentals());
            }
        }
    }
}