/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lab Informatika
 */
    public class Rental {
    private final String namaPenyewa;
    private final String namaBuku;
    private final String tipeBuku;
    private final String nomor;
    private int durasi;
    private final int totalBiaya;

    public Rental(String namaPenyewa, String namaBuku, String tipeBuku, String nomor, int duras) {
        this.namaPenyewa = namaPenyewa;
        this.namaBuku = namaBuku;
        this.tipeBuku = tipeBuku;
        this.nomor = nomor;
        this.durasi = durasi;
        this.totalBiaya = calculateCost(durasi);
    }

    private int calculateCost(int durasi) {
        int baseRate = 10000;
        int extraRate = 5000;
        if (durasi <= 2) {
            return durasi * baseRate;
        } else {
            return (2 * baseRate) + ((durasi - 2) * extraRate);
        }
    }
    }




