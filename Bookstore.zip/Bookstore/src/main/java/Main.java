
public class Main {
    public static void main(String[] args) {
        RentalView view = new RentalView();
        RentalDAO model = new RentalDAO();
        RentalController controller = new RentalController(view, model);
        view.setVisible(true);
    } 
}
