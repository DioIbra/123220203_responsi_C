
import java.awt.List;

class JFrame {
    private static class JTextField {
        public JTextField() {
        }
        private JTextField(int i) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
        private String getText() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class JTable {
        public JTable() {
        }
        private JTable(RentalTableModel tableModel) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
        private int getSelectedRow() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class RentalTableModel {
        public RentalTableModel() {
        }
    }

    private static class JPanel {
        public JPanel() {
        }
        private void setLayout(GridLayout gridLayout) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
        private void add(JLabel jLabel) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
        private void add(JTextField renterNameField) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
        private void add(JButton addButton) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class GridLayout {
        public GridLayout(int i, int i0) {
        }
    }

    private static class JLabel {
        public JLabel(String renter_Name) {
        }
    }

    private static class JScrollPane {
        public JScrollPane() {
        }
        private JScrollPane(JTable rentalTable) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class BorderLayout {

        public BorderLayout() {
        }
    }
public class RentalView extends JFrame {
    private final JTextField namaPenyewaField = new JTextField(20);
    private final JTextField namaBukuField = new JTextField(20);
    private final JTextField tipeBukuField = new JTextField(20);
    private final JTextField nomorField = new JTextField(20);
    private final JTextField durasiField = new JTextField(20);
    private final JButton addButton = new JButton("Add Rental");
    private final JButton editButton = new JButton("Edit Rental");
    private final JButton deleteButton = new JButton("Delete Rental");
    private final JTable rentalTable;
    private final RentalTableModel tableModel;

    public RentalView() {
        setTitle("Awikwok Bookstore Rental Management");
        setSize(600, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));
        panel.add(new JLabel("Nama Penyewa:"));
        panel.add(namaPenyewaField);
        panel.add(new JLabel("Nama Buku:"));
        panel.add(namaBukuField);
        panel.add(new JLabel("Tipe Buku:"));
        panel.add(tipeBukuField);
        panel.add(new JLabel("Nomor:"));
        panel.add(nomorField);
        panel.add(new JLabel("Durasi (days):"));
        panel.add(durasiField);
        panel.add(addButton);
        panel.add(editButton);
        panel.add(deleteButton);

        tableModel = new RentalTableModel();
        rentalTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(rentalTable);
    }

    public String getRenterName() {
        return namaPenyewaField.getText();
    }

    public String getBookName() {
        return namaBukuField.getText();
    }

    public String getBookType() {
        return tipeBukuField.getText();
    }

    public String getPhoneNumber() {
        return nomorField.getText();
    }

    public int getDuration() {
        return Integer.parseInt(durasiField.getText());
    }

    public int getSelectedRow() {
        return rentalTable.getSelectedRow();
    }

    public void addRentalListener(ActionListener listener) {
        addButton.addActionListener(listener);
    }

    public void editRentalListener(ActionListener listener) {
        editButton.addActionListener(listener);
    }

    public void deleteRentalListener(ActionListener listener) {
        deleteButton.addActionListener(listener);
    }

        private void setTitle(String awikwok_Bookstore_Rental_Management) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setSize(int i, int i0) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setLocationRelativeTo(Object object) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
}
}