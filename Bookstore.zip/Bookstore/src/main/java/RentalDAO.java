
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lab Informatika
 */
public class RentalDAO {
    private List<Rental> rentals = new ArrayList<>();

    public void addRental(Rental rental) {
        rentals.add(rental);
    }

    public void updateRental(int index, Rental rental) {
        rentals.set(index, rental);
    }

    public void deleteRental(int index) {
        rentals.remove(index);
    }

    public List<Rental> getRentals() {
        return rentals;
    }

    public Rental getRental(int index) {
        return rentals.get(index);
    }

    void tambahRental(Rental rental) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void hapusRental(int selectedRow) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
